module Main (main) where

import Formas

main = do
  print (area (Trapezio 10 5 2))
