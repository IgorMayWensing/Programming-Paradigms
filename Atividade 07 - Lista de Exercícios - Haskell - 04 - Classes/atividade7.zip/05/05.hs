main = do
    -- Retorna o valor absoluto
    print("Metodo ABS:")
    print (abs 10)
    print (abs (- 10))
