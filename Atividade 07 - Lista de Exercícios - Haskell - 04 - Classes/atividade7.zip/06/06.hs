main = do
    -- Retorna o menor dos dois valores
    print("Metodo min:")
    print (min 5 10)
    print (min 10 5)
    -- Retorna o maior dos dois valores
    print("Metodo max:")
    print (max 5 10)
    print (max 10 5)
