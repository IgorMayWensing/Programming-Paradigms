main = do
    -- Arredonda sempre para cima
    print("Metodo Ceiling:")
    print (ceiling 10.1)
    print (ceiling 10.9)
    -- Arredonda sempre para baixo
    print("Metodo Floor:")
    print (floor 10.1)
    print (floor 10.9)
